type Apple = {
  kind: string;
  price: number;
}

export { Apple };
