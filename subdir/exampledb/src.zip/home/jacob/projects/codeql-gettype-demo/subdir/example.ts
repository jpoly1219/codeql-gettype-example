import { Apple } from "./types";

const getApplePrice = (a: Apple): number => {
  return a.price;
}
